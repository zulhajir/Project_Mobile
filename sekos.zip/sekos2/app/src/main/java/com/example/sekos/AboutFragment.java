package com.example.sekos;

import android.content.Context;
import android.os.Bundle;
import android.text.util.Linkify;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

public class AboutFragment extends Fragment {

    public AboutFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_about, container, false);

        // Set up the social media links
        TextView socialMediaLinks = view.findViewById(R.id.socialMediaLinks);
        TextView socialMediaLinksnay = view.findViewById(R.id.socialMediaLinksnay);
        TextView socialMediaLinksjir = view.findViewById(R.id.socialMediaLinksjir);

        // Linkify social media links automatically
        Linkify.addLinks(socialMediaLinks, Linkify.ALL);
        Linkify.addLinks(socialMediaLinksnay, Linkify.ALL);
        Linkify.addLinks(socialMediaLinksjir, Linkify.ALL);

        return view;
    }
}
