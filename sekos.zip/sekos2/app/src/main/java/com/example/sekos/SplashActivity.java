package com.example.sekos;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Inisialisasi logo
        ImageView logo1 = findViewById(R.id.logo1);

        // Animasi Fade In
        Animation fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in);

        // Tampilkan logo pertama dengan animasi
        logo1.setVisibility(ImageView.VISIBLE);
        logo1.startAnimation(fadeIn);

        // Pindah ke MainActivity setelah animasi selesai
        new Handler().postDelayed(() -> {
            // Pindah ke MainActivity
            Intent intent = new Intent(SplashActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        }, 2000); // Delay untuk menunggu animasi selesai (misalnya 2 detik)
    }
}
