package com.example.sekos;

import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.squareup.picasso.Picasso;

import android.content.SharedPreferences;

public class ItemDetailActivity extends AppCompatActivity {

    private FirebaseFirestore db;
    private SharedPreferences sharedPreferences;

    private ImageButton btnLike; // Tombol Like
    private boolean isLiked; // Status like
    private String itemId;  // ID item yang diklik

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);

        // Inisialisasi Firestore dan SharedPreferences
        db = FirebaseFirestore.getInstance();
        sharedPreferences = getSharedPreferences("LikePrefs", MODE_PRIVATE);

        // Ambil ID item yang dikirim dari intent
        itemId = getIntent().getStringExtra("item_name");

        // Temukan view dalam layout
        TextView itemTitle = findViewById(R.id.itemName);
        TextView itemDescription = findViewById(R.id.itemdescrip);
        ImageView itemImage = findViewById(R.id.itemImage);
        TextView itemPriceTextView = findViewById(R.id.itemPrice);
        TextView itemFacilities = findViewById(R.id.itemFacilities);
        btnLike = findViewById(R.id.btnLike); // Tombol like

        // Cek status like dari SharedPreferences
        isLiked = sharedPreferences.getBoolean(itemId, false);
        updateLikeButton();

        // Event ketika tombol like ditekan
        btnLike.setOnClickListener(v -> {
            isLiked = !isLiked; // Toggle status like

            // Simpan status like ke SharedPreferences
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean(itemId, isLiked);  // Menyimpan status like dengan ID item
            editor.apply();

            // Perbarui tampilan tombol like
            updateLikeButton();



            // Tampilkan pesan
            if (isLiked) {
                Toast.makeText(this, "Liked!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Unliked!", Toast.LENGTH_SHORT).show();
            }
        });


        // Ambil data item berdasarkan itemId dari Firestore
        db.collection("items").whereEqualTo("name", itemId) // Filter berdasarkan itemId
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        QuerySnapshot snapshots = task.getResult();
                        if (!snapshots.isEmpty()) {
                            QueryDocumentSnapshot document = (QueryDocumentSnapshot) snapshots.getDocuments().get(0); // Ambil dokumen pertama yang ditemukan
                            // Ambil data item
                            String name = document.getString("name");
                            String description = document.getString("description");
                            String price = document.getString("price");
                            String imageUrl = document.getString("imageUrl");
                            String facilities = document.getString("facilitas");

                            // Tampilkan data ke tampilan
                            itemTitle.setText(name);
                            itemDescription.setText(description);
                            itemPriceTextView.setText(price);
                            itemFacilities.setText(facilities);

                            // Load gambar menggunakan Picasso
                            if (imageUrl != null && !imageUrl.isEmpty()) {
                                Picasso.get().load(imageUrl).into(itemImage);
                            }
                        } else {
                            Toast.makeText(this, "Item not found", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(this, "Failed to load item data", Toast.LENGTH_SHORT).show();
                    }
                });
    }


    // Metode untuk memperbarui tampilan tombol like
    private void updateLikeButton() {
        if (isLiked) {
            btnLike.setImageResource(R.drawable.ic_heart_filled); // Ikon hati penuh
        } else {
            btnLike.setImageResource(R.drawable.ic_heart_outline); // Ikon hati kosong
        }
    }
}
