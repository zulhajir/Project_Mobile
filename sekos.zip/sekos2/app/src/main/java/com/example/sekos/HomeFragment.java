package com.example.sekos;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private ItemAdapter adapter;
    private List<Item> items;

    private FirebaseFirestore db;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // Initialize Firestore
        db = FirebaseFirestore.getInstance();

        // Initialize RecyclerView
        RecyclerView recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Initialize item list
        items = new ArrayList<>();

        // Fetch data from Firestore
        fetchItemsFromFirestore(recyclerView);

        return view;
    }

    private void fetchItemsFromFirestore(RecyclerView recyclerView) {
        // Pastikan database Firestore telah diinisialisasi (db = FirebaseFirestore.getInstance())
        db.collection("items") // Gantilah "items" dengan nama koleksi Anda
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        QuerySnapshot documentSnapshots = task.getResult();

                        if (documentSnapshots != null && !documentSnapshots.isEmpty()) {
                            items.clear(); // Bersihkan daftar untuk menghindari duplikasi data

                            for (QueryDocumentSnapshot document : documentSnapshots) {
                                // Ambil setiap field dari dokumen
                                String name = document.contains("name") ? document.getString("name") : "Unknown";
                                String price = document.contains("price") ? document.getString("price") : "0";
                                String description = document.contains("description") ? document.getString("description") : "No description";
                                String imageUrl = document.contains("imageUrl") ? document.getString("imageUrl") : "";
                                String facilitas = document.contains("facilitas") ? document.getString("facilitas") : "No facilities";

                                // Tambahkan objek ke dalam daftar
                                items.add(new Item(name, price, description, imageUrl, facilitas));
                            }
                            List<Item> limitedItems = items.size() > 3 ? items.subList(0, 3) : items;

                            // Set up RecyclerView adapter dengan daftar terbatas
                            adapter = new ItemAdapter(getContext(), limitedItems);
                            recyclerView.setAdapter(adapter);
                        } else {
                            System.out.println("No documents found in the collection.");
                        }
                    } else {
                        System.out.println("Error getting documents: " + task.getException());
                    }
                });
    }
}
