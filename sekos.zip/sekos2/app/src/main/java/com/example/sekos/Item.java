package com.example.sekos;

public class Item {

    private String name;
    private String price;
    private String description;
    private String facilitas;
    private String imageUrl;  // Ganti imageResId menjadi imageUrl

    // Konstruktor kosong diperlukan untuk Firestore
    public Item() {}

    public Item(String name, String price, String description, String imageUrl, String facilitas) {
        this.name = name;
        this.price = price;
        this.description = description;
        this.imageUrl = imageUrl;
        this.facilitas = facilitas;
        // Menyimpan URL gambar

    }

    public String getName() {
        return name;
    }

    public String getPrice() {
        return price;
    }

    public String getDescription() {
        return description;
    }

    public String getImageUrl() {
        return imageUrl;  // Ambil URL gambar
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Item item = (Item) obj;
        return name != null ? name.equals(item.name) : item.name == null;
    }

    @Override
    public int hashCode() {
        return name != null ? name.hashCode() : 0;
    }
}
