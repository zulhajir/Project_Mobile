package com.example.sekos;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.SearchView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class SearchFragment extends Fragment {

    private ItemAdapter adapter;
    private List<Item> items;
    private FirebaseFirestore db;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_search, container, false);

        db = FirebaseFirestore.getInstance();

        // Initialize RecyclerView
        RecyclerView recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Initialize item list
        items = new ArrayList<>();

        // Fetch data from Firestore
        fetchItemsFromFirestore(recyclerView);

        // Initialize SearchView and link it with the adapter
        SearchView searchView = view.findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // Handle query submission if needed
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                // Filter the items as the query changes
                if (adapter != null) {
                    adapter.filter(newText);  // Call filter method in adapter
                }
                return false;  // Return false to allow other actions
            }
        });

        return view;
    }

    private void fetchItemsFromFirestore(RecyclerView recyclerView) {
        db.collection("items")  // Gantilah "items" dengan nama koleksi yang sesuai
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        QuerySnapshot documentSnapshots = task.getResult();
                        for (QueryDocumentSnapshot document : documentSnapshots) {
                            // Ambil data dari Firestore
                            String name = document.getString("name");
                            String price = document.getString("price");
                            String description = document.getString("description");
                            String imageUrl = document.getString("imageUrl");
                            String facilitas = document.getString("facilitas");

                            // Tambahkan item ke dalam list
                            items.add(new Item(name, price, description, imageUrl, facilitas));
                        }

                        // Set up the adapter with the fetched data
                        adapter = new ItemAdapter(getContext(), items);
                        recyclerView.setAdapter(adapter);
                    } else {
                        // Jika gagal mengambil data
                        System.out.println("Error getting documents: " + task.getException());
                    }
                });
    }
}
