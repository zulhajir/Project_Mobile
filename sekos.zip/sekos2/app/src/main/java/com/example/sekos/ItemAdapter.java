package com.example.sekos;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemViewHolder> {

    private List<Item> itemList;
    private List<Item> filteredItemList;  // Hapus static, sehingga ini milik setiap instance
    private Context context;

    public ItemAdapter(Context context, List<Item> itemList) {
        this.context = context;
        this.itemList = itemList;
        this.filteredItemList = new ArrayList<>(itemList);  // Salin data item list untuk filter
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {
        TextView textViewItem, textViewItemDescription, textViewItemPrice;
        ImageView imageViewItem, iconNext;
        LinearLayout itemLayout;

        public ItemViewHolder(View itemView) {
            super(itemView);
            textViewItem = itemView.findViewById(R.id.textViewItemTitle);
            textViewItemDescription = itemView.findViewById(R.id.textViewItemdescripstion);
            textViewItemPrice = itemView.findViewById(R.id.textViewItemPrice);
            imageViewItem = itemView.findViewById(R.id.imageViewItem);
            iconNext = itemView.findViewById(R.id.iconNext);
            itemLayout = itemView.findViewById(R.id.itemLayout);  // Root LinearLayout

            // Set the on-click listener for itemLayout to trigger the intent
            itemLayout.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    // Ambil item yang dipilih
                    Item clickedItem = filteredItemList.get(position);
                    // Intent untuk membuka ItemDetailActivity
                    Intent intent = new Intent(itemView.getContext(), ItemDetailActivity.class);
                    intent.putExtra("item_name", clickedItem.getName());
                    intent.putExtra("item_description", clickedItem.getDescription());
                    intent.putExtra("item_image_url", clickedItem.getImageUrl());  // Menggunakan URL gambar
                    intent.putExtra("item_price", clickedItem.getPrice());  // Menggunakan URL gambar
                    itemView.getContext().startActivity(intent);
                }
            });
        }
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        Item currentItem = filteredItemList.get(position);
        holder.textViewItem.setText(currentItem.getName());
        holder.textViewItemDescription.setText(currentItem.getDescription());
        holder.textViewItemPrice.setText(currentItem.getPrice());

        // Memeriksa apakah URL gambar valid
        String imageUrl = currentItem.getImageUrl();
        if (imageUrl != null && !imageUrl.isEmpty()) {
            Glide.with(context)
                    .load(imageUrl)  // Mengambil URL gambar dari Item
                    .into(holder.imageViewItem);
        } else {
            holder.imageViewItem.setImageResource(R.drawable.ic_placeholder_image);  // Jika gambar kosong, set gambar placeholder
        }
    }

    @Override
    public int getItemCount() {
        return filteredItemList.size();
    }

    // Method untuk filter data berdasarkan query
    public void filter(String query) {
        filteredItemList.clear();  // Kosongkan list yang difilter
        if (query.isEmpty()) {
            filteredItemList.addAll(itemList);  // Jika tidak ada query, tampilkan semua item
        } else {
            for (Item item : itemList) {
                if (item.getName().toLowerCase().contains(query.toLowerCase())) {
                    filteredItemList.add(item);  // Menambahkan item yang cocok dengan query
                }
            }
        }
        notifyDataSetChanged();  // Mengupdate RecyclerView
    }

    // Method untuk update data adapter
    public void updateData(List<Item> newItems) {
        this.itemList = newItems;
        this.filteredItemList = new ArrayList<>(newItems);  // Update filtered item list
        notifyDataSetChanged();  // Memberitahukan adapter untuk update data
    }
}
